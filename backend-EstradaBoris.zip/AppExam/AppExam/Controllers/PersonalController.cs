﻿using AppExam.models;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Data;
namespace AppExam.Controllers
{
    [ApiController]
    [Route("api/personal")]
    public class PersonalController:ControllerBase
    {
        public readonly IConfiguration _configuration;
        private readonly SqlConnection _sqlConnection;
        public PersonalController( IConfiguration configuration )
        {
            // realizar inicializaciones
            _configuration = configuration;
            _sqlConnection = new SqlConnection(configuration.GetConnectionString("ExamAppCon"));
        }

        [HttpGet("listar")]
        public async Task<IActionResult> ListPersonal()
        {
            // Utilizar la conexión existente en lugar de crear una nueva
            await _sqlConnection.OpenAsync();

            // Utilizar Dapper para ejecutar el procedimiento almacenado
            var parameters = new DynamicParameters();
            // Ajustar y agregar parámetros según sea necesario
            var personal = await _sqlConnection.QueryAsync<Personal>("ListarPersonal", parameters, commandType: CommandType.StoredProcedure);

            _sqlConnection.Close();

            return Ok(personal);
        }

        [HttpGet("searchPersonal")]
        public async Task<IActionResult> searchPersonal( string terminoBusqueda)
        {
            var parameters = new { TerminoBusqueda = terminoBusqueda }; // Parámetro para el término de búsqueda

            // validar si la conexión está abierta antes de realizar la consulta
            if (_sqlConnection.State != ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }

            var empleadosEncontrados = await _sqlConnection.QueryAsync<Personal>("BuscarEmpleados", parameters, commandType: CommandType.StoredProcedure);
            _sqlConnection.Close();

            return Ok(empleadosEncontrados);

        }

        [HttpGet("searchPersonalId")]
        public async Task<IActionResult> searchPersonalId( string id)
        {
            try
            {
                var parameters = new { EmpleadoId = id }; // Parámetro para el término de búsqueda

                // validar si la conexión está abierta antes de realizar la consulta
                if (_sqlConnection.State != ConnectionState.Open)
                {
                    await _sqlConnection.OpenAsync();
                }

                var empleadosEncontrados = await _sqlConnection.QueryFirstOrDefaultAsync<Personal>("BuscarEmpleadoPorId", parameters, commandType: CommandType.StoredProcedure);
                _sqlConnection.Close();

                return Ok(empleadosEncontrados);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "Error interno al buscar el registro del personal", StatusCode = 500 });
            }

        }

        [HttpPost("")]
        public async Task<IActionResult> SavePersonal(Personal personal)
        {
            try
            {
                // validar si la conexión está abierta antes de realizar la operación de guardado
                if (_sqlConnection.State != ConnectionState.Open)
                {
                    await _sqlConnection.OpenAsync();
                }

                var parameters = new
                {
                    personal.TipoDoc,
                    personal.NumeroDoc,
                    personal.ApPaterno,
                    personal.ApMaterno,
                    personal.Nombre1,
                    personal.Nombre2,
                    personal.FechaNac,
                    personal.FechaIngreso
                };

                // Utilizar Dapper para ejecutar el procedimiento almacenado
                await _sqlConnection.ExecuteAsync("CrearPersonal", parameters, commandType: CommandType.StoredProcedure);

                _sqlConnection.Close();

                return Ok(new { Message = "Registro de personal guardado con éxito", StatusCode = 200 });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "Error interno al guardar el registro de personal", StatusCode = 500 });
            }
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdatePersonal(int id, Personal updatedPersonal)
        {
            try
            {
                // validar si la conexión está abierta antes de realizar la operación de actualización
                if (_sqlConnection.State != ConnectionState.Open)
                {
                    await _sqlConnection.OpenAsync();
                }

                // Agregar el ID al objeto actualizado
                var parameters = new
                {
                    Id = id,
                    TipoDoc = updatedPersonal.TipoDoc,
                    NumeroDoc = updatedPersonal.NumeroDoc,
                    ApPaterno = updatedPersonal.ApPaterno,
                    ApMaterno = updatedPersonal.ApMaterno,
                    Nombre1 = updatedPersonal.Nombre1,
                    Nombre2 = updatedPersonal.Nombre2,
                    FechaNac = updatedPersonal.FechaNac,
                    FechaIngreso = updatedPersonal.FechaIngreso
                };

                // Ejecutar el procedimiento almacenado para actualizar el registro de personal
                await _sqlConnection.ExecuteAsync("ActualizarPersonal", parameters, commandType: CommandType.StoredProcedure);

                _sqlConnection.Close();

                return Ok(new { Message = "Registro de personal actualizado con éxito", StatusCode = 200 });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "Error interno al actualizar el registro del personal", StatusCode = 500 });
            }
        }

        [HttpDelete("eliminar")]
        public async Task<IActionResult> DeletePersonal(int id)
        {
            // validar si la conexión está abierta antes de realizar la operación de eliminación
            if (_sqlConnection.State != ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }
            // eliminar el registro de personal
            await _sqlConnection.ExecuteAsync("EliminarPersonal", new { Id = id }, commandType: CommandType.StoredProcedure);

            _sqlConnection.Close();

            return Ok("Registro de personal y sus hijos eliminado con éxito");
        }

        

    }
}
