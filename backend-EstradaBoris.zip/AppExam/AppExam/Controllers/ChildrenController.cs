﻿using AppExam.models;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;


namespace AppExam.Controllers
{
    [ApiController]
    [Route("api/children")]
    public class ChildrenController : ControllerBase
    {
        public readonly IConfiguration _configuration;
        private readonly SqlConnection _sqlConnection;

        public ChildrenController(IConfiguration configuration)
        {
            // realizar inicializaciones
            _configuration = configuration;
            _sqlConnection = new SqlConnection(configuration.GetConnectionString("ExamAppCon"));
        }

        [HttpGet("listar/{id}")]
        public async Task<IActionResult> ListChildren(string id)
        {
            var parameters = new { IdPersonal = id }; // Parámetro para el término de búsqueda
            // validar si la conexión está abierta antes de realizar la consulta
            if (_sqlConnection.State != ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }

            // Ajustar y agregar parámetros según sea necesario
            var children = await _sqlConnection.QueryAsync<Children>("ListarHijosPorIdPersonal", parameters, commandType: CommandType.StoredProcedure);

            _sqlConnection.Close();

            return Ok(children);
        }

        [HttpGet("searchChild")]
        public async Task<IActionResult> searchChild(string terminoBusqueda, string idPersonal)
        {
            var parameters = new {
                TerminoBusqueda = terminoBusqueda,
                IdPersonal = idPersonal
            }; // Parámetro para el término de búsqueda

            // validar si la conexión está abierta antes de realizar la consulta
            if (_sqlConnection.State != ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }

            var childEncontrados = await _sqlConnection.QueryAsync<Children>("BuscarHijos", parameters, commandType: CommandType.StoredProcedure);
            _sqlConnection.Close();

            return Ok(childEncontrados);
        }

        [HttpGet("searchChildId")]
        public async Task<IActionResult> searchChildId(string id, string idPersonal)
        {
            try
            {
                var parameters = new {
                    ChildId = id,
                    PersonalId = idPersonal
                }; // Parámetro para el término de búsqueda

                // validar si la conexión está abierta antes de realizar la consulta
                if (_sqlConnection.State != ConnectionState.Open)
                {
                    await _sqlConnection.OpenAsync();
                }

                var childEncontrados = await _sqlConnection.QueryFirstOrDefaultAsync<Children>("BuscarChildPorId", parameters, commandType: CommandType.StoredProcedure);
                _sqlConnection.Close();

                return Ok(childEncontrados);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "Error interno al buscar el registro del hijo", StatusCode = 500 });
            }

        }

        [HttpPost("")]
        public async Task<IActionResult> SaveChild(Children child)
        {
            try
            {
                // validar si la conexión está abierta antes de realizar la operación de guardado
                if (_sqlConnection.State != ConnectionState.Open)
                {
                    await _sqlConnection.OpenAsync();
                }

                var parameters = new
                {
                    child.TipoDoc,
                    child.NumeroDoc,
                    child.ApPaterno,
                    child.ApMaterno,
                    child.Nombre1,
                    child.Nombre2,
                    child.FechaNac,
                    child.IdPersonal
                };

                // Utilizar Dapper para ejecutar el procedimiento almacenado
                await _sqlConnection.ExecuteAsync("CrearHijo", parameters, commandType: CommandType.StoredProcedure);

                _sqlConnection.Close();

                return Ok(new { Message = "Registro del hijo guardado con éxito", StatusCode = 200 });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "Error interno al guardar el registro del hijo", StatusCode = 500 });
            }
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateChild(int id, Children updatedChild)
        {
            try
            {
                // validar si la conexión está abierta antes de realizar la operación de actualización
                if (_sqlConnection.State != ConnectionState.Open)
                {
                    await _sqlConnection.OpenAsync();
                }

                // Agregar el ID al objeto actualizado
                var parameters = new
                {
                    Id = id,
                    TipoDoc = updatedChild.TipoDoc,
                    NumeroDoc = updatedChild.NumeroDoc,
                    ApPaterno = updatedChild.ApPaterno,
                    ApMaterno = updatedChild.ApMaterno,
                    Nombre1 = updatedChild.Nombre1,
                    Nombre2 = updatedChild.Nombre2,
                    FechaNac = updatedChild.FechaNac,
                    IdPersonal = updatedChild.IdPersonal
                };

                // Ejecutar el procedimiento almacenado para actualizar el registro de personal
                await _sqlConnection.ExecuteAsync("ActualizarHijo", parameters, commandType: CommandType.StoredProcedure);

                _sqlConnection.Close();

                return Ok(new { Message = "Registro del hijo actualizado con éxito", StatusCode = 200 });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "Error interno al actualizar el registro del hijo", StatusCode = 500 });
            }
        }

        [HttpDelete("eliminar")]
        public async Task<IActionResult> DeleteChildren(int id)
        {
            // validar si la conexión está abierta antes de realizar la operación de eliminación
            if (_sqlConnection.State != ConnectionState.Open)
            {
                await _sqlConnection.OpenAsync();
            }
            // eliminar el registro de hijo
            await _sqlConnection.ExecuteAsync("EliminarHijo", new { Id = id }, commandType: CommandType.StoredProcedure);

            _sqlConnection.Close();

            return Ok("Registro del hijo fue eliminado con éxito");
        }


    }

}
