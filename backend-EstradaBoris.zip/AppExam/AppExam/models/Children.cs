﻿namespace AppExam.models
{
    public class Children
    {
        public string Id { get; set; }
        public string TipoDoc { get; set; }
        public string NumeroDoc { get; set; }
        public string ApPaterno { get; set; }
        public string ApMaterno { get; set; }
        public string Nombre1 { get; set; }
        public string Nombre2 { get; set; }
        public string? NombreCompleto { get; set; }
        public DateTime FechaNac { get; set; }

        // Representa la relación con la tabla Personal
        public string IdPersonal { get; set; }
    }
}
