
-- Cambiar al contexto de la base de datos ApellidoNombre
USE EstradaBoris;
GO

DROP TABLE Hijos;


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Hijos')
	DROP TABLE Hijos
-- Crear la tabla Hijos
BEGIN
	CREATE TABLE Hijos (
		Id INT IDENTITY(1,1) PRIMARY KEY,
		IdPersonal INT,
		TipoDoc VARCHAR(50),
		NumeroDoc VARCHAR(50),
		ApPaterno VARCHAR(50),
		ApMaterno VARCHAR(50),
		Nombre1 VARCHAR(50),
		Nombre2 VARCHAR(50),
		NombreCompleto AS ApPaterno + ' ' + ApMaterno + ', ' + Nombre1 + ' ' + Nombre2,
		FechaNac DATE,
		FOREIGN KEY (IdPersonal) REFERENCES Personal(Id)
	);
END;


/*************************/

CREATE PROCEDURE ListarTodosLosHijos
AS
BEGIN
    SELECT * FROM Hijos;
END;

/***/

CREATE PROCEDURE ListarHijosPorIdPersonal
    @IdPersonal INT
AS
BEGIN
    SELECT * FROM Hijos WHERE IdPersonal = @IdPersonal;
END;

/***/

CREATE PROCEDURE CrearHijo
    @IdPersonal INT,
    @TipoDoc VARCHAR(50),
    @NumeroDoc VARCHAR(50),
    @ApPaterno VARCHAR(50),
    @ApMaterno VARCHAR(50),
    @Nombre1 VARCHAR(50),
    @Nombre2 VARCHAR(50),
    @FechaNac DATE
AS
BEGIN
    INSERT INTO Hijos (IdPersonal, TipoDoc, NumeroDoc, ApPaterno, ApMaterno, Nombre1, Nombre2, FechaNac)
    VALUES (@IdPersonal, @TipoDoc, @NumeroDoc, @ApPaterno, @ApMaterno, @Nombre1, @Nombre2, @FechaNac);
END;

/***/

CREATE PROCEDURE ActualizarHijo
    @Id INT,
	@IdPersonal INT,
    @TipoDoc VARCHAR(50),
    @NumeroDoc VARCHAR(50),
    @ApPaterno VARCHAR(50),
    @ApMaterno VARCHAR(50),
    @Nombre1 VARCHAR(50),
    @Nombre2 VARCHAR(50),
    @FechaNac DATE
AS
BEGIN
    UPDATE Hijos
    SET TipoDoc = @TipoDoc,
        NumeroDoc = @NumeroDoc,
        ApPaterno = @ApPaterno,
        ApMaterno = @ApMaterno,
        Nombre1 = @Nombre1,
        Nombre2 = @Nombre2,
        FechaNac = @FechaNac
    WHERE Id = @Id;
END;

/***/

CREATE PROCEDURE EliminarHijo
    @Id INT
AS
BEGIN
    DELETE FROM Hijos WHERE Id = @Id;
END;

/*****/

CREATE PROCEDURE BuscarHijos
    @TerminoBusqueda NVARCHAR(100),
	@IdPersonal INT
AS
BEGIN
    SELECT *
    FROM Hijos
    WHERE (ApPaterno LIKE '%' + @TerminoBusqueda + '%'
        OR ApMaterno LIKE '%' + @TerminoBusqueda + '%'
        OR Nombre1 LIKE '%' + @TerminoBusqueda + '%'
        OR Nombre2 LIKE '%' + @TerminoBusqueda + '%'
		OR NombreCompleto LIKE '%' + @terminoBusqueda + '%')
		AND IdPersonal = @IdPersonal;
END;


CREATE PROCEDURE BuscarChildPorId
    @ChildId INT,
    @PersonalId INT
AS
BEGIN
    SELECT *
    FROM Hijos
    WHERE Id = @ChildId and IdPersonal = @PersonalId;
END;

SELECT * FROM Hijos
select * from Personal

TRUNCATE TABLE Hijos;
TRUNCATE TABLE Personal;
DELETE FROM Personal WHERE id > 1;
