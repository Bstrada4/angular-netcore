-- Crear la base de datos con nombre ApellidoNombre
CREATE DATABASE EstradaBoris;
GO

-- Cambiar al contexto de la base de datos ApellidoNombre
USE EstradaBoris;
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Personal')
	DROP TABLE Personal;
BEGIN
    -- Crea la tabla solo si no existe
    CREATE TABLE Personal (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        TipoDoc VARCHAR(50),
        NumeroDoc VARCHAR(50),
        ApPaterno VARCHAR(50),
        ApMaterno VARCHAR(50),
        Nombre1 VARCHAR(50),
        Nombre2 VARCHAR(50),
        NombreCompleto AS ApPaterno + ' ' + ApMaterno + ', ' + Nombre1 + ' ' + Nombre2,
        FechaNac DATE,
        FechaIngreso DATE
    );
END;

-- Procedimiento almacenado para listar todo el personal
CREATE PROCEDURE ListarPersonal
AS
BEGIN
    SELECT * FROM Personal;
END;

---- Crear un procedimiento almacenado para realizar la uni�n
--CREATE PROCEDURE ObtenerHijosPorPersonal
--    @IdPersonal INT
--AS
--BEGIN
--    SELECT Personal.*, Hijos.*
--    FROM Personal
--    LEFT JOIN Hijos ON Personal.Id = Hijos.IdPersonal
--    WHERE Personal.Id = @IdPersonal;
--END;


-- Procedimiento almacenado para crear personal
CREATE PROCEDURE CrearPersonal
    @TipoDoc VARCHAR(50),
    @NumeroDoc VARCHAR(50),
    @ApPaterno VARCHAR(50),
    @ApMaterno VARCHAR(50),
    @Nombre1 VARCHAR(50),
    @Nombre2 VARCHAR(50),
    @FechaNac DATE,
    @FechaIngreso DATE
AS
BEGIN
    INSERT INTO Personal (TipoDoc, NumeroDoc, ApPaterno, ApMaterno, Nombre1, Nombre2, FechaNac, FechaIngreso)
    VALUES (@TipoDoc, @NumeroDoc, @ApPaterno, @ApMaterno, @Nombre1, @Nombre2, @FechaNac, @FechaIngreso);
END;

-- Procedimiento almacenado para actualizar personal
CREATE PROCEDURE ActualizarPersonal
    @Id INT,
    @TipoDoc VARCHAR(50),
    @NumeroDoc VARCHAR(50),
    @ApPaterno VARCHAR(50),
    @ApMaterno VARCHAR(50),
    @Nombre1 VARCHAR(50),
    @Nombre2 VARCHAR(50),
    @FechaNac DATE,
    @FechaIngreso DATE
AS
BEGIN
    UPDATE Personal
    SET
        TipoDoc = @TipoDoc,
        NumeroDoc = @NumeroDoc,
        ApPaterno = @ApPaterno,
        ApMaterno = @ApMaterno,
        Nombre1 = @Nombre1,
        Nombre2 = @Nombre2,
        FechaNac = @FechaNac,
        FechaIngreso = @FechaIngreso
    WHERE Id = @Id;
END;

-- Procedimiento almacenado para eliminar personal y sus hijos
CREATE PROCEDURE EliminarPersonal
    @Id INT
AS
BEGIN
    DELETE FROM Hijos WHERE IdPersonal = @Id;
    DELETE FROM Personal WHERE Id = @Id;
END;

CREATE PROCEDURE BuscarEmpleados
    @TerminoBusqueda NVARCHAR(100)
AS
BEGIN
    SELECT *
    FROM Personal
    WHERE Nombre1 LIKE '%' + @TerminoBusqueda + '%'
        OR Nombre2 LIKE '%' + @TerminoBusqueda + '%'
        OR ApPaterno LIKE '%' + @TerminoBusqueda + '%'
        OR ApMaterno LIKE '%' + @TerminoBusqueda + '%'
		OR NombreCompleto LIKE '%' + @terminoBusqueda + '%';

END;

CREATE PROCEDURE BuscarEmpleadoPorId
    @EmpleadoId INT
AS
BEGIN
    SELECT *
    FROM Personal
    WHERE Id = @EmpleadoId;
END;

/***************************/

-- Insertar registros ficticios en la tabla Personal
INSERT INTO Personal (TipoDoc, NumeroDoc, ApPaterno, ApMaterno, Nombre1, Nombre2, FechaNac, FechaIngreso)
VALUES
('DNI', '12345678', 'Lopez', 'Gomez', 'Carlos', 'Alberto', '1990-05-15', '2010-01-01'),
('RUC', '87654321', 'Martinez', 'Perez', 'Ana', 'Maria', '1985-08-20', '2008-04-12'),
('DNI', '98765432', 'Garcia', 'Rodriguez', 'Javier', 'Luis', '1980-02-10', '2015-09-30'),
('DNI', '56789012', 'Fernandez', 'Sanchez', 'Laura', 'Isabel', '1993-11-28', '2012-07-05'),
('RUC', '34567890', 'Diaz', 'Flores', 'Pedro', 'Alejandro', '1987-07-02', '2009-11-18'),
('DNI', '23456789', 'Vargas', 'Luna', 'Maria', 'Elena', '1998-04-05', '2017-03-22'),
('DNI', '78901234', 'Gomez', 'Hernandez', 'Sofia', 'Carmen', '1983-09-12', '2014-06-14'),
('RUC', '45678901', 'Rodriguez', 'Mendez', 'Juan', 'Carlos', '1995-12-03', '2011-02-28'),
('DNI', '90123456', 'Sanchez', 'Cruz', 'Luis', 'Miguel', '1989-06-18', '2016-10-10'),
('DNI', '12389045', 'Lopez', 'Perez', 'Isabel', 'Fernanda', '1997-01-30', '2013-08-07');

select * from Personal

-- Insertar registros ficticios en la tabla Hijos
INSERT INTO Hijos (IdPersonal, TipoDoc, NumeroDoc, ApPaterno, ApMaterno, Nombre1, Nombre2, FechaNac)
VALUES
(1, 'DNI', '23456789', 'Lopez', 'Gomez', 'Luis', 'Alberto', '2012-03-10'),
(2, 'DNI', '76543210', 'Martinez', 'Perez', 'Ana', 'Isabel', '2010-12-15'),
(3, 'DNI', '12345678', 'Garcia', 'Rodriguez', 'Sara', 'Javier', '2015-08-05'),
(4, 'DNI', '56789012', 'Fernandez', 'Sanchez', 'Daniel', 'Laura', '2018-06-25'),
(5, 'DNI', '23456789', 'Diaz', 'Flores', 'Eva', 'Pedro', '2013-11-18'),
(6, 'DNI', '56789012', 'Vargas', 'Luna', 'Julia', 'Maria', '2016-09-30'),
(7, 'DNI', '78901234', 'Gomez', 'Hernandez', 'Lucas', 'Sofia', '2014-02-08'),
(8, 'DNI', '90123456', 'Rodriguez', 'Mendez', 'Diego', 'Juan', '2011-12-20'),
(9, 'DNI', '12389045', 'Sanchez', 'Cruz', 'Elena', 'Luis', '2017-04-02'),
(10, 'DNI', '90123456', 'Lopez', 'Perez', 'Miguel', 'Isabel', '2014-10-15');

DELETE FROM Personal WHERE id >10